import {Notyf} from 'notyf'
































































































































export enum SccMsg {
    LOGIN_SUCCESS = 'Success 2 Login',
    REGISTER_SUCCESS = 'Success 2 REGISTER',
    TOTAL = 'Total',
    COUPON_FOUND = "COUPON_FOUND",
    COUPON_ADDED = "COUPON_ADDED",
    DELETE_COUPON = "DELETE_COUPON",
    UPDATE_COUPON = "UPDATE_COUPON",
    CUSTOMER_DETAILS = "CUSTOMER_DETAILS",
    Company_Details = "Company_Details",
    CATEGORY_FOUND = "CATEGORY_FOUND"
}
class Notify{

    private notification = new Notyf({duration:4000, position:{x:"left",y:"top"}});
    public success(message: string){
        this.notification.success(message);
    }

    public error(err: any){
        const msg = this.extractMsg(err);
        this.notification.error(msg);
    }

    private extractMsg(err: any): string{
        
				if(typeof err === 'string'){
            return err;
        }

        if(typeof err?.response?.data === 'string'){ 
            return err.response.data;
        }

        if(Array.isArray(err?.response?.data)){
            return err?.response?.data[0];
        }

        
				// Must be last
        if(typeof err?.message === 'string'){
            return err.message;
        }
        return "Error occurred, please try again.";
    }
}
export const notify = new Notify();