import axios from "axios";
import { useParams } from "react-router-dom";
import { CouponModel, CouponPayloadModel } from "../Models/Coupons";
import { CompanyModel, CompanyPayloadModel, CredentialsModel, CustomerModel, CustomerPayloadModel, LoginModel, UserModel } from "../Models/Users";
import globals from "./Globals";
import { tokenAxios } from "./InterceptorAxios";

class WebApi {

    private customerApi = globals.urls.customerApi;
    private companyApi = globals.urls.companyApi;
    private adminApi = globals.urls.adminApi;
    private loginApi = globals.urls.loginApi
    private registerApi = globals.urls.registerApi

    /*Login*/
    public async login(credentials: CredentialsModel): Promise<any> {
        const request:string ="?clientType="+credentials.type;
        return await axios.post<LoginModel>(this.loginApi + request, credentials);
    }
    /*Companies */
    public async CompanyDetails():Promise<any>{
        return await tokenAxios.get<CompanyModel>(this.customerApi)
    }
    public async registerCompany(credentials: CompanyPayloadModel): Promise<any> {
        return await axios.post<any>(this.registerApi + 'company', credentials);
    }
    public async countCompanyCoupons(): Promise<any> {
        return await tokenAxios.get<number>(this.companyApi + 'count');
    }
    public async getCompanyCoupons():Promise<any>{
        return await tokenAxios.get<CouponModel[]>(this.companyApi + 'coupons')
    }
    /* Customers */
    public async CustomerDetails():Promise<any>{
        return await tokenAxios.get<CustomerModel>(this.customerApi)
    }
    public async registerCustomer(credentials: CustomerPayloadModel): Promise<any> {
        return await axios.post<any>(this.registerApi + 'customer', credentials);
    }
    public async countCustomerCoupons(): Promise<any> {
        return await tokenAxios.get<number>(this.customerApi + 'count');
    }
    public async getCustomerCoupons():Promise<any>{
        return await tokenAxios.get<CouponModel[]>(this.customerApi + 'coupons')
    }
    /* Coupons */
    public async addCoupon(coupon:CouponPayloadModel):Promise<any>{
        return await tokenAxios.post<any>(this.companyApi + 'add',coupon)
    }
    public async deleteCoupon(id:number):Promise<any>{
        return await tokenAxios.delete<any>(this.companyApi + 'delete/' + id )
    }
    public async updateCoupon(id:number,coupon:CouponPayloadModel):Promise<any>{
        return await tokenAxios.put<any>(this.companyApi + 'update/' + id , coupon)
    }
    public async getAllCoupons():Promise<any>{
        return await axios.get<any>(this.adminApi + 'all/coupons')
    }
    public async PurchaseCoupon(id:number, coupon : CouponPayloadModel):Promise<any>{
        return await tokenAxios.put<any>(this.customerApi + 'purchase/' + id,coupon)
    }
    public async RefundCoupon(id:number, coupon : CouponPayloadModel):Promise<any>{
        return await tokenAxios.put<any>(this.customerApi + 'refund/' + id,coupon )
    }
    public async geCouponsByCompanyCategory(category : string|undefined):Promise<any>{
        return await tokenAxios.get<CouponModel[]>(this.companyApi + 'coupons/category?=' + category)
    }
    public async geCouponsByCustomerCategory(category : string|undefined):Promise<any>{
        return await tokenAxios.get<CouponModel[]>(this.customerApi +'coupons/category?=' + category)
    }
    public async geCouponsByCompanyPrice(price : number|undefined):Promise<any>{
        return await tokenAxios.get<CouponModel[]>(this.companyApi + 'coupons/maxPrice?=' +price )
    }
    public async geCouponsByCustomerPrice(price : number|undefined):Promise<any>{
        return await tokenAxios.get<CouponModel[]>(this.customerApi  + 'coupons/maxPrice?=' + price)
    }
    /*Admin */

}
export const web = new WebApi();