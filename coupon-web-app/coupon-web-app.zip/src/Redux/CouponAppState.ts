import { CouponModel } from "../Models/Coupons";

export class CouponAppState{
    public coupons: CouponModel[] = [];
}




export enum CouponActionType {
    CouponDeleted = "CouponDeleted",
    CouponClear = "CouponClear",
    CouponPurchased = "CouponPurchased",
    CouponRefund = "CouponRefund",
    CouponUpdated = "CouponUpdate",
    CouponsDownloaded = "CouponsDownloaded",
    CouponsBigDownloaded = "CouponsBigDownloaded"
}

export interface CouponAction {
    type : CouponActionType;
    payload?: any;
}

export function CouponDeletedAction (id : number) : CouponAction {
    return{type: CouponActionType.CouponDeleted, payload:id};
}

export function CouponUpdatedAction (coupon : CouponModel) : CouponAction {
    return{type: CouponActionType.CouponUpdated, payload:coupon};
}
/* is needed ? */
export function CouponPurchasedAction (id : number) : CouponAction {
    return{type: CouponActionType.CouponPurchased,payload:{id}};
}
/* is needed ? */ 
export function CouponRefundAction (id :  number) : CouponAction {
    return{type: CouponActionType.CouponRefund,payload:{id}};
}

export function CouponClearAction () : CouponAction {
    return{type: CouponActionType.CouponDeleted};
}

export function CouponDownloadedAction (coupons : CouponModel[]) : CouponAction {
    return{type: CouponActionType.CouponsDownloaded , payload:coupons};
}

export function couponReducer(currentState : CouponAppState = new CouponAppState(), action: CouponAction) : CouponAppState {

    const newState = { ...currentState }

    switch (action.type) {
        case CouponActionType.CouponUpdated:
            const idx = newState.coupons.findIndex(c => c.notId === action.payload.id);
            newState.coupons[idx] = action.payload;
            break;
        case CouponActionType.CouponDeleted:
            newState.coupons = newState.coupons.filter(c => c.notId !== action.payload.id);
            break;
        case CouponActionType.CouponClear:
            newState.coupons = [];
            break;
        case CouponActionType.CouponsDownloaded:
            newState.coupons = action.payload;
            break;
        default:
            return {...currentState};
        }
        return newState
}
