import { CouponModel } from "../Models/Coupons";
import { CompanyModel, CustomerModel, UserModel } from "../Models/Users";

export class AuthAppState {
    public user: UserModel | null= new UserModel();
    public constructor(){
        try 
        {
            const storedUser = JSON.parse(localStorage.getItem("user")||"");
            if (storedUser){
                this.user = storedUser;
            }
        }
        catch
        {
            this.user = null;
        }
    }
}
export enum AuthActionType {
    Register = "register",
    Login = "login",
    Logout = "logout",
    customerUpdated = "customerUpdated",
    customerDeleted = "customerDeleted",
    Download = "Download",
    Update = "Update",
    Remove = "Remove"
}
export interface AuthAction {
    type : AuthActionType;
    payload?:any;
}
export function registerAction(): AuthAction {
    return { type: AuthActionType.Register };
}

export function loginAction(user: UserModel): AuthAction {
    return { type: AuthActionType.Login, payload: user };
}

export function logoutAction(): AuthAction {
    return { type: AuthActionType.Logout };
}
export function DownloadCouponsAction(coupons : CouponModel[]) :AuthAction{
    return{type:AuthActionType.Download, payload:coupons}
}
export function UpdateCouponsAction(coupons : CouponModel) :AuthAction{
    return{type:AuthActionType.Update, payload:coupons}
}
export function RemoveCouponsAction(id : number) :AuthAction{
    return{type:AuthActionType.Remove, payload:id}
}


export function authReducer(currentState: AuthAppState = new AuthAppState(),
    action: AuthAction): AuthAppState {

    const newState = { ...currentState }
    switch (action.type) {
        case AuthActionType.Register:
            break;
        case AuthActionType.Login:
            newState.user = action.payload;
            localStorage.setItem("user", JSON.stringify(newState.user)); 
            break;
        case AuthActionType.Logout:
            newState.user = null;
            localStorage.removeItem("user");
            break;
    }
    return newState;
}