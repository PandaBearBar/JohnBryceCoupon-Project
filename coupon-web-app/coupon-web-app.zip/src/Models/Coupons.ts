import { date } from "yup";

export class CouponModel{
    [x: string]: any;
    public notId?: number;
    public notPrice?: number;
    public notAmount?: number;
    public notTitle?: string;
    public notDesc?:string;
    public notCategory?: string;
    public notImg?:string;
    public notStartDate?: Date;
    public notEndDate?: Date;
    public constructor (notId?: number,notPrice?: number,notAmount?: number,notTitle?: string,notDesc?:string,notCategory?: string,notImg?:string,notStartDate?: Date,notEndDate?: Date){
        this.notId = notId;
        this.notPrice = notPrice;
        this.notAmount = notAmount;
        this.notTitle = notTitle;
        this.notDesc = notDesc;
        this.notCategory = notCategory;
        this.notImg = notImg;
        this.notStartDate = notStartDate;
        this.notEndDate = notEndDate;
    }
}

export class CouponPayloadModel{
    public notPrice?: number;
    public notAmount?: number;
    public notTitle?: string;
    public notDesc?:string;
    public notCategory?: string;
    public notImg?:string;
    public notStartDate?: Date;
    public notEndDate?: Date;

    public constructor (notPrice?: number,notAmount?: number,notTitle?: string,notDesc?:string,notCategory?: string,notImg?:string,notStartDate?: Date,notEndDate?: Date){
        
        this.notPrice = notPrice;
        this.notAmount = notAmount;
        this.notTitle = notTitle;
        this.notDesc = notDesc;
        this.notCategory = notCategory;
        this.notImg = notImg;
        this.notStartDate = notStartDate;
        this.notEndDate = notEndDate;
    }
}

