import React from 'react'
import { MdOutlineCategory} from 'react-icons/md'
import { FaMoneyBill} from 'react-icons/fa'
import { NavLink } from 'react-router-dom'
import './Searching.css';

export const Searchi:React.FC = () => {
    return (
        <div className='Searching'>
            <NavLink  to={'/search/category'}><MdOutlineCategory size={45}/></NavLink>
            <NavLink  to={'/search/price'}><FaMoneyBill size={45}/></NavLink>
        </div>
    )
}
