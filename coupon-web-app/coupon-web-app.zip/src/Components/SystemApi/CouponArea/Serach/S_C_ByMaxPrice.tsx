import React, { useEffect, useState } from 'react'
import { CouponModel, CouponPayloadModel } from '../../../../Models/Coupons';
import { CouponDownloadedAction } from '../../../../Redux/CouponAppState';
import store from '../../../../Redux/Store';
import { notify, SccMsg } from '../../../../Service/notify';
import { web } from '../../../../Service/WebAPi';
import { BootCoupon } from '../../../PageArea/BootCoupon/BootCoupon';
import { EmptyView } from '../../../PageArea/EmptyView/EmptyView';
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';

export const SCByCMaxPrice = () => {
    const [coupons, setCoupons] = useState<CouponModel[]>(store.getState().couponReducer.coupons); 
    const type = store.getState().authReducer?.user?.clientType;
    
    const schema = yup.object().shape({
    notPrice:
        yup.number()
        .moreThan(0)
        .required()
    });
    const {register,handleSubmit,formState:{errors,isDirty,isValid}} = 
        useForm<CouponPayloadModel>({mode:'all',resolver:yupResolver(schema)});

    const search = async(coupon:CouponPayloadModel) => {
        switch(type){
            case "Company":
                web.geCouponsByCompanyPrice(coupon.notPrice)
                    .then(res =>{
                        notify.success(SccMsg.CATEGORY_FOUND);
                        store.dispatch(CouponDownloadedAction(res.data));
                        })
                    .catch(err =>{
                    notify.error('Oppsy :' + err.message);
                    });
                break;
            case "Customer" :
                web.geCouponsByCustomerPrice(coupon.notPrice)
                    .then(res =>{
                        notify.success(SccMsg.CATEGORY_FOUND);
                        store.dispatch(CouponDownloadedAction(res.data));
                        })
                    .catch(err =>{
                    notify.error('Oppsy :' + err.message);
                    });
                break;
            }
        } 
    return(
        <div className="CouponList">
            <form onSubmit={handleSubmit(search)} className="flex-center-col">
            <div>
                <label htmlFor="notPrice">Price : </label>
                <input {...register('notPrice')} type="text" placeholder='Ex.420.69'  id='notPrice'/>
                <span>{errors.notPrice?.message}</span>
            </div>
            <button className="button-success" disabled={!isValid}>Add</button>
        </form>
        <div>
        {
            (coupons.length > 0)
            ?
            coupons.map(c => <BootCoupon key={c.notId} coupon={c} owned={true} />)
            :
            <></>
        }
        </div>
    </div>
    );
}