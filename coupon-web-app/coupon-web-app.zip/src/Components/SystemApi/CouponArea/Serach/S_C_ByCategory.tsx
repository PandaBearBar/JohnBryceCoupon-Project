import React, { useEffect, useState } from 'react'
import { CouponModel, CouponPayloadModel } from '../../../../Models/Coupons';
import { CouponDownloadedAction } from '../../../../Redux/CouponAppState';
import store from '../../../../Redux/Store';
import { notify, SccMsg } from '../../../../Service/notify';
import { web } from '../../../../Service/WebAPi';
import { BootCoupon } from '../../../PageArea/BootCoupon/BootCoupon';
import { EmptyView } from '../../../PageArea/EmptyView/EmptyView';
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';

export const SCByCategory = () => {
    const [coupons, setCoupons] = useState<CouponModel[]>(store.getState().couponReducer.coupons); 
    const type = store.getState().authReducer?.user?.clientType;

    const Category = ["Food","Electricity","Restaurant","Vacation"];
    const schema = yup.object().shape({
    notCategory :
    yup.mixed()
        .oneOf(Category)
        .required()
    });
    const {register,handleSubmit,formState:{errors,isDirty,isValid}} = 
        useForm<CouponPayloadModel>({mode:'all',resolver:yupResolver(schema)});

    const search = async(coupon:CouponPayloadModel) => {
        switch(type){
            case "Company":
                web.geCouponsByCompanyCategory(coupon.notCategory)
                    .then(res =>{
                        notify.success(SccMsg.CATEGORY_FOUND);
                        store.dispatch(CouponDownloadedAction(res.data));
                        })
                    .catch(err =>{
                    notify.error('Oppsy :' + err.message);
                    });
                break;
            case "Customer" :
                web.geCouponsByCustomerCategory(coupon.notCategory)
                    .then(res =>{
                        notify.success(SccMsg.CATEGORY_FOUND);
                        store.dispatch(CouponDownloadedAction(res.data));
                        })
                    .catch(err =>{
                    notify.error('Oppsy :' + err.message);
                    });
                break;
            }
        } 
    return(
        <div className="CouponList">
            <form onSubmit={handleSubmit(search)} className="flex-center-col">
                <div>
                    <label htmlFor="notCategory">Category : </label>
                    <input {...register('notCategory')} type="text"  id='notCategory'/>
                    <span>{errors.notPrice?.message}</span>
                </div>
            <button className="button-success" disabled={!isValid}>Add</button>
        </form>
        <div>
        {
            (coupons.length > 0)
            ?
            coupons.map(c => <BootCoupon key={c.notId} coupon={c} owned={true} />)
            :
            <></>
        }
        </div>
    </div>
    );
}