import { yupResolver } from '@hookform/resolvers/yup';
import { now } from 'moment';
import React from 'react'
import { Button } from 'react-bootstrap';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom'
import * as yup from 'yup'
import { CouponPayloadModel } from '../../../../Models/Coupons';
import { CouponDownloadedAction } from '../../../../Redux/CouponAppState';
import store from '../../../../Redux/Store';
import { notify, SccMsg } from '../../../../Service/notify';
import { web } from '../../../../Service/WebAPi';

export const AddCoupon:React.FC = () => {
    const Category = ["Food","Electricity","Restaurant","Vacation"];
    const navigate = useNavigate();
    const schema = yup.object().shape({
        notPrice:
            yup.number()
                .moreThan(0)
                .required(),
        notAmount:
            yup.number()
                .moreThan(0)
                .integer("Must be naturel number")
                .required(),
        notTitle : 
            yup.string()
                .required(),
        notDesc :
            yup.string()
                .required(),
        notCategory :
            yup.mixed()
                .oneOf(Category)
                .required(),
        notImg :
            yup.string()
                .required(),
        notStartDate:
            yup.date()
                .min(new Date(), 'Umm... past due date? come on!')
                .default(new Date(Date.now()))
                .typeError("You must specify a due date")
                .required("due date is required")
                .nullable().default(() => new Date()),
        notEndDate:
            yup.date()
                .min(new Date(), 'Umm... past due date? come on!')
                .default(new Date())
                .typeError("You must specify a due date")
                .required("due date is required")
                .nullable().default(() => new Date(Date.now() + 6.048e+8))
    });

    const {register,handleSubmit,formState:{errors,isDirty,isValid}} = 
        useForm<CouponPayloadModel>({mode:'all',resolver:yupResolver(schema)});

    const Add = async(coupon : CouponPayloadModel) => {
        console.log(coupon);
        console.log(JSON.stringify(coupon));

        web.addCoupon(coupon)
            .then(res =>{
                notify.success(SccMsg.COUPON_ADDED);
                navigate('/owned');
                store.dispatch(CouponDownloadedAction(res.data));
            })
            .catch(err =>{
                notify.error('Oppsy :' + err.message);
                navigate('/add');
            });
    };


    return (
        <div>
        <h1>Add Coupon :</h1>
        <form onSubmit={handleSubmit(Add)} className="flex-center-col">
            <div>
                <label htmlFor="notTitle">Title : </label>
                <input {...register('notTitle')} type="text" placeholder='Ex.Best Coupon In D World'  id='notTitle'/>
                <span>{errors.notTitle?.message}</span>
            </div>
            <div>
                <label htmlFor="notDesc">Description : </label>
                <input {...register('notDesc')} type="text" placeholder='Ex.Omg! its MAGIC in a cup'  id='notDesc'/>
                <span>{errors.notDesc?.message}</span>
            </div>
            <div>
                <label htmlFor="notCategory">Category : </label>
                <input {...register('notCategory')} type="text"  id='notCategory'/>
                <span>{errors.notPrice?.message}</span>
            </div>
            <div>
            <label htmlFor="notPrice">Price : </label>
                <input {...register('notPrice')} type="text" placeholder='Ex.420.69'  id='notPrice'/>
                <span>{errors.notPrice?.message}</span>
            </div>
            <div>
                <label htmlFor="notAmount">Amount : </label>
                <input {...register('notAmount')} type="number" placeholder='Ex.10'  id='notAmount'/>
                <span>{errors.notAmount?.message}</span>
            </div>
            <div>
                <label htmlFor="notImg">Image URL : </label>
                <input {...register('notImg')} type="text" placeholder='http:\\findItUrSelf.com'  id='notImg'/>
                <span>{errors.notImg?.message}</span>
            </div>
            <div>
                <label htmlFor="notStartDate"> Start @ : </label>
                <input {...register('notStartDate')} type="date" placeholder='dd/MM/yy'  id='notStartDate'/>
                <span>{errors.notStartDate?.message}</span>
            </div>
            <div>
                <label htmlFor="notEndDate"> End @ : </label>
                <input {...register('notEndDate')} type="date" placeholder='dd/MM/yy'  id='notEndDate'/>
                <span>{errors.notEndDate?.message}</span>
            </div>
            <button className="button-success" disabled={!isValid}>Add</button>
        </form>
        </div>
    )
}
