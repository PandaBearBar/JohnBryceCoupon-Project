import SwaggerUI from "swagger-ui-react"
import "swagger-ui-react/swagger-ui.css"

const AdminSwagger = () => <SwaggerUI url="http://localhost:8080/swagger-ui.html" />
export default AdminSwagger;