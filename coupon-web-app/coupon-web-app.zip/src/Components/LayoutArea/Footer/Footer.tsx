import React from 'react'
import { NavLink } from 'react-router-dom'
import { SocialMedia } from '../../SocialMedia/SocialMedia'

const Footer:React.FC = () => {
    return (
        <div className = "Footer">
            <p>All Rights 2 Bar Saadi</p>
            <SocialMedia />
            <div>
            <NavLink to = "/admin">This is a secret</NavLink>
            </div>
        </div>
    )
}

export default Footer