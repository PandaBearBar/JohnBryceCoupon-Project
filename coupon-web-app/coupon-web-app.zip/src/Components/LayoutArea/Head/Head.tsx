import React from 'react'
import { NavLink } from 'react-router-dom'
import { AuthMenu } from '../../AuthArea/AuthMenu/AuthMenu'
import './NavbarOverwrite.css'
import { OwnedIcon } from '../../PageArea/Cart/OwnedIcon'
import {AiOutlineHome, AiOutlineInfoCircle} from 'react-icons/ai'
import {FiShoppingBag} from 'react-icons/fi'
import {FaDonate} from 'react-icons/fa'
import { Clock } from '../../PageArea/ClockTime/Clock'
import { RiCoupon3Line } from 'react-icons/ri'
import { FcViewDetails } from 'react-icons/fc'
import { BiSearchAlt } from 'react-icons/bi'
import { Info } from '../../PageArea/Info/Info'

export const Head:React.FC= () => {
    return (
        <nav className = "navbar navbar-expand-lg navbar-dark bg-dark">
            <Clock/>
            <NavLink  className={"navbar-brand"} to={'/search'}><BiSearchAlt size={45}/></NavLink>
            <NavLink  className={"navbar-brand"} to={'/'}><AiOutlineHome size={45}/></NavLink>
            <NavLink  className={"navbar-brand"} to={'/catalog'}><FiShoppingBag size={45}/></NavLink>
            <NavLink  className={"navbar-brand"} to={'/about'}><AiOutlineInfoCircle size={45}/></NavLink>
            <NavLink  className={"navbar-brand"} to={'/donate'}><FaDonate size={45} /></NavLink>
            <NavLink  className={"navbar-brand"} to={'/owned'}><OwnedIcon /><RiCoupon3Line size={30} /></NavLink>
            <NavLink  className={"navbar-brand"} to={'/info'}><FcViewDetails size={30} /></NavLink>
            <AuthMenu />
        </nav>
    )
}