import React, { useEffect, useState } from 'react'
import { RiCoupon3Line } from 'react-icons/ri';
import store from '../../../Redux/Store';
import { notify, SccMsg } from '../../../Service/notify';
import { web } from '../../../Service/WebAPi';
import { Circle } from '../Circle/Circle';


export const OwnedIcon = () => {
    const [num, setNum] = useState(store.getState().couponReducer.coupons.length ?? 0 );
    const type = store.getState().authReducer?.user?.clientType;
    useEffect(() => {
        if(num === 0){
            switch(type){
            case "Company":
                setNum(0);
                web.countCompanyCoupons()
                    .then(res=>{
                        setNum(res.data);
                        notify.success(SccMsg.TOTAL + res.data);
                    })
                    .catch(err => notify.error(err.message))
            return;
            case "Customer":
                setNum(0);
                web.countCustomerCoupons()
                    .then(res=>{
                        setNum(res.data);
                        notify.success(SccMsg.TOTAL + res.data);
                    })
                    .catch(err => notify.error(err.message))
            return;
            default:
                console.log("def")
                setNum(0);
            return;
            }
        }
        return store.subscribe(() => {
            setNum(store.getState().couponReducer.coupons.length);
        })
    }, []);
    
    return (
        <div>
            <Circle num={num} />
        </div>
    );
}