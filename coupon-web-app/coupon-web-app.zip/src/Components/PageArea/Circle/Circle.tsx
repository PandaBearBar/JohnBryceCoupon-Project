import { useState } from "react";
import './Circle.css'

interface CircleProps {
    num:number;
}
export function Circle(props:CircleProps){
    const[num,setNum] = useState(props.num);
    return(
        <div className="Circle">{props.num}</div>
    );
}