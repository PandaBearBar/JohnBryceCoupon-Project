import moment from 'moment';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { CompanyModel, CompanyPayloadModel, CustomerModel, CustomerPayloadModel } from '../../../Models/Users';
import store from '../../../Redux/Store'
import { notify, SccMsg } from '../../../Service/notify';
import { web } from '../../../Service/WebAPi';
import { CouponList } from '../../SystemApi/CouponArea/CouponLIst/CouponList';
import './Info.css'

export const Info = () => {
    const navigate = useNavigate();
    const type = store.getState().authReducer.user?.clientType;
    switch(type){     
        case "Company" :
            const [company,setCompany] = useState<CompanyModel>();
            web.CompanyDetails()
                .then(res=> {
                    notify.success(SccMsg.Company_Details);
                    const setCompany = new CompanyModel(res.data.notEmail,
                                                        res.data.notPassword,
                                                        res.data.notName,
                                                        res.data.notCoupons);
                })
                .catch(err => {
                    notify.error(err.message);
                });
            return (
                <div className='Info' >
                    <img className="card-img-top" src="https://cataas.com/cat/gif" alt="Card image cap" />
                    <div className="card-body">
                        <h5 className="card-title">Hello {company?.notName}</h5>
                        <ul className="list-group list-group-flush">
                            <li className="list-group-item">Name : {company?.notEmail}</li>
                            <li className="list-group-item">Amount : {company?.notPassword}</li>
                            <li className="list-group-item">Price: {company?.notName}</li>
                        </ul>
                    </div>
                </div>
            )
        case "Customer":
            const [customer,setCustomer] = useState<CustomerModel>();
            web.CustomerDetails()
                .then(res=> {
                    notify.success(SccMsg.CUSTOMER_DETAILS);
                    const setCustomer = new CustomerModel(res.data.notEmail,
                                                        res.data.notPassword,
                                                        res.data.notFirstName,
                                                        res.data.notLastName,
                                                        res.data.notCoupons);
                })
                .catch(err => {
                    notify.error(err.message);
                });
            return (
                <div className='Info'>
                    <img className="card-img-top" src="https://cataas.com/cat/gif" alt="Card image cap" />
                    <div className="card-body">
                        <h5 className="card-title">Hello {customer?.notFirstName}</h5>
                        <ul className="list-group list-group-flush">
                            <li className="list-group-item">Name : {customer?.notEmail}</li>
                            <li className="list-group-item">Amount : {customer?.notPassword}</li>
                            <li className="list-group-item">Price: {customer?.notFirstName}</li>
                            <li className="list-group-item">Price: {customer?.notLastName}</li>
                        </ul>
                    </div>
                </div>
            )
        default:
            return (
                <div>
                    <h1>Hello there Anonymous </h1>
                    <img src="https://c.tenor.com/GRceXwOglroAAAAM/anonymous-cat.gif" alt="Anonymous client" />
                </div>
            )
    }
}
