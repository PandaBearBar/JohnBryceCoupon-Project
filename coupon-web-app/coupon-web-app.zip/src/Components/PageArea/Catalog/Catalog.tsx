import React, { useEffect, useState } from 'react'
import { CouponModel } from '../../../Models/Coupons';
import { CouponDownloadedAction } from '../../../Redux/CouponAppState';
import store from '../../../Redux/Store';
import { notify, SccMsg } from '../../../Service/notify';
import { web } from '../../../Service/WebAPi';
import { BootCoupon } from '../BootCoupon/BootCoupon';
import '../../SystemApi/CouponArea/CouponLIst/CouponList.css'

export const Catalog:React.FC = () => {
  const [coupons, setCoupons] = useState<CouponModel[]>(store.getState().couponReducer.coupons);
  useEffect(()=>{
    if(store.getState().couponReducer.coupons.length === 0){
        web.getAllCoupons()
        .then((res)=>{
            notify.success(SccMsg.COUPON_FOUND);
            setCoupons(res.data);
            store.dispatch(CouponDownloadedAction(coupons))
        })
        .catch((err)=>{
            notify.error(err.message);
        });
    }
}, [coupons]);
  return (
    <div className='CouponList'>
      {coupons.map(c => <BootCoupon key={c.notId} coupon={c} owned={false} />)}
    </div>
  )
  
}
