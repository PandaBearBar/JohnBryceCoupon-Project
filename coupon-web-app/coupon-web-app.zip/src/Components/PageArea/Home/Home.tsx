import React from 'react'
import store from '../../../Redux/Store'

export const Home:React.FC = () => {
    const token = store.getState().authReducer.user?.token;
    return (
        <div>
            <div><img src="https://media0.giphy.com/media/lQTvKuycxCxi5cVo2I/giphy.gif?cid=ecf05e47eeyvg0du2qy2su2jwsjyuepxkokp4dyx078axz92&rid=giphy.gif&ct=g" alt="Hello There" /></div>
            <div><img src="https://i0.wp.com/www.dailycal.org/assets/uploads/2013/11/despicableme.gif" alt="shopping" /></div>
        </div>
    )
}
