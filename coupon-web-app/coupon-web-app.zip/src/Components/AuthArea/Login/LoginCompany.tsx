import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import { NavLink, useNavigate } from "react-router-dom";
import * as yup from "yup";
import { LoginModel, CredentialsModel, UserModel } from "../../../Models/Users";
import store from "../../../Redux/Store";
import { loginAction } from "../../../Redux/UserAppState";
import { notify, SccMsg } from "../../../Service/notify";
import { web } from "../../../Service/WebAPi";




export const LoginCompany:React.FC = () => {
    const navigate = useNavigate();
    const schema = yup.object().shape({
        email:
            yup.string()
                .email("Invalid Email Pattern")
                .required("Email is required"),
        password:
            yup.string()
                .required("Password is required")
                .min(4, "min 4")
                .max(16, "max 16")
    });
    const { register, handleSubmit, formState: { errors, isDirty, isValid } } =
        useForm<LoginModel>({ mode: "all", resolver: yupResolver(schema) });

    const loginUser = async (model: LoginModel) => {
        const credentials = new CredentialsModel();
        credentials.email = model.email;
        credentials.password = model.password;
        credentials.type = "Company";

        console.log('going to send to remote server...' + credentials);

        web.login(credentials)
            .then((res) => {
                notify.success(SccMsg.LOGIN_SUCCESS);
                store.dispatch(loginAction(res.data));
                navigate('/');
            })
            .catch(err => {
                notify.error(err.message);
            });
    }

    return (
        <div className="Login flex-center-col">
            <h1>Login As :</h1>
            <span><NavLink className= {"btn btn-sm btn-outline-secondary"} to = "/login/customer"> Customer </NavLink></span>
            <span><NavLink className={"btn btn-outline-success"} to = "/login/company"> Company </NavLink></span>
            <form onSubmit={handleSubmit(loginUser)} className="flex-center-col">
                <label htmlFor="email">Email</label>
                <input {...register("email")} type="email" placeholder="email" id="email" />
                <span>{errors.email?.message}</span>
                <div></div>
                <label htmlFor="password">Password</label>
                <input  {...register("password")} type="password" placeholder="password" id="password" />
                <span>{errors.password?.message}</span>
                <div></div>
                    <button className="button-success" disabled={!isValid}>Login</button>
            </form>
            <div>
                <span>not a member ? </span>
                <NavLink to = "/register/company"> Register </NavLink>
            </div>
        </div>
    );
}
