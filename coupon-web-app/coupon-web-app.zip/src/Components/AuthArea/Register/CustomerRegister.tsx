import { yupResolver } from '@hookform/resolvers/yup';
import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useForm } from "react-hook-form";
import * as yup from 'yup'
import { CustomerPayloadModel } from '../../../Models/Users';
import {web} from '../../../Service/WebAPi';
import {notify, SccMsg } from '../../../Service/notify';
import store from '../../../Redux/Store';
import { registerAction } from '../../../Redux/UserAppState';

export const CustomerRegister = () => {
    const navigate = useNavigate();
    const schema = yup.object().shape({
        notEmail:
            yup.string()
                .email("Invalid Email Pattern")
                .required("Email is required"),
        notPassword:
            yup.string()
                .min(4, "at least 4")
                .max(16, "at most 16")
                .required("Password is required"),
        notFirstName:
            yup.string()
                .min(2,"at least 2")
                .max(20,"u took it to far `\(*_*)/`")
                .required("first name is required"),
        notLastName:
            yup.string()
                .min(2,"at least 2")
                .max(20,"u took it to far `\(*_*)/`")
                .required("first name is required")
    })
    const { register, handleSubmit, formState: { errors, isDirty, isValid } } =
        useForm<CustomerPayloadModel>({ mode: "all", resolver: yupResolver(schema) });
    
    const registerCustomer = async(user:CustomerPayloadModel) => {
        console.log(user);
        console.log(JSON.stringify(user));

        web.registerCustomer(user)
            .then(res => {
                notify.success(SccMsg.REGISTER_SUCCESS);
                navigate("/login/customer");
                store.dispatch(registerAction());
            })
            .catch(err => { 
                notify.error('Oppsy : ' + err.message);
                navigate('/register/customer');
            });
    }
    return (
        <div>
            <h1>Register as : </h1>
            <span><NavLink className={"btn btn-outline-success"} to = "/register/customer"> Customer </NavLink></span>
            <span><NavLink className={"btn btn-sm btn-outline-secondary"} to = "/register/company"> Company </NavLink></span>
            <form onSubmit={handleSubmit(registerCustomer)} className="flex-center-col">
                <label htmlFor="email">email</label>
                <input {...register("notEmail")} type="email" placeholder="email" id="email" />
                <span>{errors.notEmail?.message}</span>
                <div></div>
                <label htmlFor="password">password</label>
                <input  {...register("notPassword")} type="password" placeholder="password" id="password" />
                <span>{errors.notPassword?.message}</span>
                <div></div>
                <label htmlFor="first name">first name</label>
                <input  {...register("notFirstName")} type="text" placeholder="first name" id="first name" />
                <span>{errors.notFirstName?.message}</span>
                <div></div>
                <label htmlFor="last name">last name</label>
                <input  {...register("notLastName")} type="text" placeholder="last name" id="last name" />
                <span>{errors.notLastName?.message}</span>
                <div></div>
                <button className="button-success" disabled={!isValid}>Register</button>
            </form>
            <div>
                <span>member ? </span>
                <NavLink to = "/login/customer"> Login </NavLink>
            </div>
        </div>
    )
}
