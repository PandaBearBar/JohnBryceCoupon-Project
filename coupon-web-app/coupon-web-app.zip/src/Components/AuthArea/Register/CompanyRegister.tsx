import { yupResolver } from '@hookform/resolvers/yup';
import React from 'react'
import { useForm } from 'react-hook-form';
import { NavLink, useNavigate } from 'react-router-dom'
import * as yup from 'yup'
import { CompanyPayloadModel } from '../../../Models/Users';
import store from '../../../Redux/Store';
import { registerAction } from '../../../Redux/UserAppState';
import {notify, SccMsg } from '../../../Service/notify';
import {web} from '../../../Service/WebAPi';

export const CompanyRegister = () => {
    const navigate = useNavigate();
    const schema = yup.object().shape({
        notEmail:
            yup.string()
                .email("Invalid Email Pattern")
                .required("Email is required"),
        notPassword:
            yup.string()
                .min(4, "at least 4")
                .max(16, "at most 16")
                .required("Password is required"),
        notName:
            yup.string()
                .min(2,"at least 2")
                .max(20,"u took it to far `\(*_*)/`")
                .required("first name is required")
    })
    const { register, handleSubmit, formState: { errors, isDirty, isValid } } =
        useForm<CompanyPayloadModel>({ mode: "all", resolver: yupResolver(schema) });
    
    const registerCustomer = async(user:CompanyPayloadModel) => {
        console.log(user);
        console.log(JSON.stringify(user));

        web.registerCompany(user)
            .then(res => {
                notify.success(SccMsg.REGISTER_SUCCESS);
                navigate("/login/company");
                store.dispatch(registerAction());
            })
            .catch(err => { 
                notify.error('Oppsy : ' + err.message);
                navigate('/register/company');
            });
    }
    return (
        <div>
            <h1>Register as : </h1>
            <span><NavLink className={"btn btn-sm btn-outline-secondary"} to = "/register/customer"> Customer </NavLink></span>
            <span><NavLink  className={"btn btn-outline-success"} to = "/register/company"> Company </NavLink></span>
            <form onSubmit={handleSubmit(registerCustomer)} className="flex-center-col">
                <label htmlFor="email">email</label>
                <input {...register("notEmail")} type="email" placeholder="email" id="email" />
                <span>{errors.notEmail?.message}</span>
                <div></div>
                <label htmlFor="password">password</label>
                <input  {...register("notPassword")} type="password" placeholder="password" id="password" />
                <span>{errors.notPassword?.message}</span>
                <div></div>
                <label htmlFor="name">name</label>
                <input  {...register("notName")} type="text" placeholder=" name" id=" name" />
                <span>{errors.notName?.message}</span>
                <div></div>
                <button className="button-success" disabled={!isValid}>Register</button>
            </form>
            <div>
                <span>member ? </span>
                <NavLink to = "/login/company"> Login </NavLink>
            </div>
        </div>
    )
}