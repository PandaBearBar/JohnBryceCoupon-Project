import React from 'react'
import { Route, Routes } from 'react-router-dom'
import {Home} from '../../PageArea/Home/Home'
import {About} from '../../PageArea/About/About'
import {Donate} from '../../PageArea/Donate/Donate'
import {Page404} from '../../PageArea/Page404/Page404'
import { Logout } from '../../AuthArea/Logout/Logout'
import {CustomerRegister} from '../../AuthArea/Register/CustomerRegister'
import {CompanyRegister} from '../../AuthArea/Register/CompanyRegister'
import { LoginCompany } from '../../AuthArea/Login/LoginCompany'
import { LoginCustomer } from '../../AuthArea/Login/LoginCustomer'
import {Catalog} from '../../PageArea/Catalog/Catalog'
import { CouponList } from '../../SystemApi/CouponArea/CouponLIst/CouponList'
import { AddCoupon } from '../../SystemApi/CouponArea/AddCoupon/AddCoupon'
import { Owner } from '../../PageArea/Cart/Owner'
import { DeleteCoupon } from '../../SystemApi/CouponArea/DeleteCoupon/DeleteCoupon'
import {UpdateCoupon} from '../../SystemApi/CouponArea/UpdateCoupon/UpdateCoupon'
import {CouponPurchase} from '../../SystemApi/CouponArea/CouponPurchase/CouponPurchase'
import {CouponRefund} from '../../SystemApi/CouponArea/CouponRefund/CouponRefund'
import { Info } from '../../PageArea/Info/Info'
import { Searchi } from '../../SystemApi/CouponArea/Serach/searching'
import { SCByCMaxPrice } from '../../SystemApi/CouponArea/Serach/S_C_ByMaxPrice'
import { SCByCategory } from '../../SystemApi/CouponArea/Serach/S_C_ByCategory'
import AdminSwagger from '../../SystemApi/AdminArea/AdminSwagger'
import { LoginAdmin } from '../../SystemApi/AdminArea/AdminLogin'

const Routing:React.FC = () => {
    return (
        <>
            <Routes>
                <Route path='/' element={<Home />} />
                <Route path='/about' element={<About />} />
                <Route path='/donate' element={<Donate />} />
                <Route path="/register/customer" element={<CustomerRegister />} />
                <Route path="/register/company" element={<CompanyRegister />} />
                <Route path="/login/customer" element={<LoginCustomer />} />
                <Route path="/login/company" element={<LoginCompany />} />
                <Route path="/logout" element={<Logout />} />
                <Route path="/owned" element={<Owner />} />
                <Route path="/catalog" element={<Catalog />} />
                <Route path="/add" element={<AddCoupon />} />
                <Route path="/delete/:id" element={<DeleteCoupon />} />
                <Route  path="/update/:id" element = {<UpdateCoupon/>}  />
                <Route path="/refund/:id" element={<CouponRefund />} />
                <Route path="/purchase/:id" element={<CouponPurchase />} />
                <Route path="/info" element={<Info />} />
                <Route path="/search" element={<Searchi />} />
                <Route path="/search/price" element={<SCByCMaxPrice />} />
                <Route path="/search/category" element={<SCByCategory />} />
                <Route path="/swag" element={<AdminSwagger />} />
                <Route path="/admin" element={<LoginAdmin />} />
                <Route path='*' element={<Page404 />} />
            </Routes>
            
        </>
    )
}

export default Routing